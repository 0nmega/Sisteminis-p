#include <string>
#include <vector>

struct Studentas {
  std::string vardas;
  std::string pavardė;
  std::vector<int> namu_darbai;
  int egzaminas;
  double galutinis;
};

void skaiciuotiGalutini(Studentas &studentas);
void isvestiRezultatus(const Studentas &studentas, bool useMedian);
