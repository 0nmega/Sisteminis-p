
#include "studentas.h"
#include <iomanip>
#include <iostream>

void skaiciuotiGalutini(Studentas &studentas) {
  double vidurkis = 0.0;
  if (!studentas.namu_darbai.empty()) {
    for (int nd : studentas.namu_darbai) {
      vidurkis += nd;
    }
    vidurkis /= studentas.namu_darbai.size();
  }
  studentas.galutinis = 0.4 * vidurkis + 0.6 * studentas.egzaminas;
}

void isvestiRezultatus(const Studentas &studentas, bool useMedian) {
  std::cout << std::left << std::setw(12) << studentas.pavardė << std::setw(12)
            << studentas.vardas << std::setw(20);
  if (useMedian) {
    std::cout << std::fixed << std::setprecision(2) << studentas.galutinis;
  } else {
    std::cout << std::fixed << std::setprecision(2) << studentas.galutinis;
  }
  std::cout << std::endl;
}
