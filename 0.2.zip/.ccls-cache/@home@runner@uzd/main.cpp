#include "studentas.h"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdlib.h>
#include <vector>

void isvestiVisusRezultatus(const std::vector<Studentas> &studentai,
                            bool useMedian) {
  std::cout << std::left << std::setw(12) << "Pavardė" << std::setw(12)
            << "Vardas" << std::setw(20) << "Galutinis "
            << (useMedian ? "(Med.)" : "(Vid.)") << std::endl;
  std::cout << std::string(46, '-') << std::endl;

  for (const auto &studentas : studentai) {
    isvestiRezultatus(studentas, useMedian);
  }
}

int main() {
  std::vector<Studentas> studentai;

  // Paprasčiau įvesti duomenis
  int n;
  std::cout << "Įveskite studentų skaičių: ";
  std::cin >> n;

  for (int i = 0; i < n; ++i) {
    Studentas studentas;
    std::cout << "Įveskite studento vardą: ";
    std::cin >> studentas.vardas;
    std::cout << "Įveskite studento pavardę: ";
    std::cin >> studentas.pavardė;

    int nd;
    std::cout << "Įveskite namų darbų rezultatus (įveskite 5 įvertinimus): ";
    for (int j = 0; j < 5; ++j) {
      std::cin >> nd;
      studentas.namu_darbai.push_back(nd);
    }

    std::cout << "Įveskite egzamino rezultatą: ";
    std::cin >> studentas.egzaminas;

    skaiciuotiGalutini(studentas);
    studentai.push_back(studentas);
  }

  // Rezultatų išvedimas
  isvestiVisusRezultatus(studentai, false); // Pagal vidurkį
  isvestiVisusRezultatus(studentai, true);  // Pagal medianą

  return 0;
}
